package towers.model

class GridLocation(val x: Int, val y: Int) 
{
   override def toString() : String = {
       return x + " " + y;
   } 
    
}